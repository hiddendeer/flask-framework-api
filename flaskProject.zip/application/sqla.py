# from flask import Flask
#
#
# app = Flask(__name__)
#
# # 数据库配置
# HOSTNAME = '127.0.0.1'
# PORT = '3306'
# DATABASE = 'flask-admin'
# USERNAME = 'root'
# PASSWORD = '123456'
#
# DB_URI = 'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(USERNAME, PASSWORD, HOSTNAME, PORT, DATABASE)
# app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
#
#
#
